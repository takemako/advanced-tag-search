<?php
/**
 * 管理画面設定
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 設定ページのレンダリング
 */
function ats_render_settings_page() {
    // 権限チェック
    if (!current_user_can('manage_options')) {
        wp_die(__('このページにアクセスする権限がありません。', 'advanced-tag-search'));
    }
    
    // 設定の保存処理
    if (isset($_POST['ats_save_settings']) && check_admin_referer('ats_settings_nonce')) {
        ats_save_settings();
        echo '<div class="notice notice-success is-dismissible"><p>' . 
             __('設定を保存しました。', 'advanced-tag-search') . '</p></div>';
    }
    
    // 現在の設定を取得
    $settings = get_option('ats_settings', array());
    $tag_manager = new ATS_Tag_Manager();
    $tag_categories = $tag_manager->get_tag_categories();
    $all_wp_tags = $tag_manager->get_all_wp_tags();
    $all_wp_categories = $tag_manager->get_all_wp_categories();
    // モーダルに表示するカテゴリーの選択（未設定の場合はnull＝全カテゴリー表示）
    $filter_categories = isset($settings['filter_categories']) && is_array($settings['filter_categories'])
        ? $settings['filter_categories']
        : null;
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <form method="post" action="">
            <?php wp_nonce_field('ats_settings_nonce'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="ats_search_title">
                            <?php _e('検索窓のタイトル', 'advanced-tag-search'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text"
                               id="ats_search_title"
                               name="ats_search_title"
                               value="<?php echo esc_attr($settings['search_title'] ?? ''); ?>"
                               class="regular-text">
                        <p class="description">
                            <?php _e('検索窓の上に表示されるタイトルを設定します（例: 川越の気になる！を探す）', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ats_placeholder">
                            <?php _e('検索窓のプレースホルダー', 'advanced-tag-search'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ats_placeholder" 
                               name="ats_placeholder" 
                               value="<?php echo esc_attr($settings['placeholder'] ?? 'タグから探してみる'); ?>" 
                               class="regular-text">
                        <p class="description">
                            <?php _e('検索窓に表示されるプレースホルダーテキストを設定します。', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ats_modal_title">
                            <?php _e('モーダルのタイトル', 'advanced-tag-search'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ats_modal_title" 
                               name="ats_modal_title" 
                               value="<?php echo esc_attr($settings['modal_title'] ?? 'タグ検索'); ?>" 
                               class="regular-text">
                        <p class="description">
                            <?php _e('モーダルウィンドウのタイトルを設定します。', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
            </table>
            
            <h2><?php _e('色設定', 'advanced-tag-search'); ?></h2>
            <p><?php _e('検索ボタンとアイコンの色をカスタマイズできます。', 'advanced-tag-search'); ?></p>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="ats_search_icon_color">
                            <?php _e('虹眼鏡アイコンの色', 'advanced-tag-search'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ats_search_icon_color" 
                               name="ats_search_icon_color" 
                               value="<?php echo esc_attr($settings['search_icon_color'] ?? '#666666'); ?>" 
                               class="ats-color-picker">
                        <p class="description">
                            <?php _e('検索窓の虹眼鏡アイコンの色を設定します。（デフォルト: #666666）', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ats_button_color">
                            <?php _e('検索ボタンの色', 'advanced-tag-search'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ats_button_color" 
                               name="ats_button_color" 
                               value="<?php echo esc_attr($settings['button_color'] ?? '#2196F3'); ?>" 
                               class="ats-color-picker">
                        <p class="description">
                            <?php _e('モーダル内の「絞り込む」ボタンの色を設定します。（デフォルト: #2196F3）', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
            </table>
            
            
            <h2><?php _e('タグカテゴリー設定', 'advanced-tag-search'); ?></h2>
            <p><?php _e('各カテゴリーに表示するタグを、WordPressに登録済みのタグから選択してください。', 'advanced-tag-search'); ?></p>
            
            <table class="form-table">
                <?php foreach ($tag_categories as $category_key => $category_data): ?>
                <tr>
                    <th scope="row">
                        <label for="ats_category_title_<?php echo esc_attr($category_key); ?>">
                            <?php _e('カテゴリー名', 'advanced-tag-search'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ats_category_title_<?php echo esc_attr($category_key); ?>"
                               name="ats_category_title[<?php echo esc_attr($category_key); ?>]" 
                               value="<?php echo esc_attr($category_data['title']); ?>"
                               class="regular-text"
                               placeholder="<?php echo esc_attr($category_data['title']); ?>">
                        <p class="description">
                            <?php _e('モーダルに表示されるカテゴリー名を設定します（例: ジャンルから絞り込む）', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label>
                            <?php _e('タグ選択', 'advanced-tag-search'); ?>
                        </label>
                    </th>
                    <td>
                        <?php if (empty($all_wp_tags)): ?>
                            <p class="description">
                                <?php
                                printf(
                                    wp_kses(
                                        __('WordPressにタグが登録されていません。先に<a href="%s">タグを作成</a>してください。', 'advanced-tag-search'),
                                        array('a' => array('href' => array()))
                                    ),
                                    esc_url(admin_url('edit-tags.php?taxonomy=post_tag'))
                                );
                                ?>
                            </p>
                        <?php else: ?>
                            <p class="ats-checkbox-toolbar">
                                <button type="button" class="button button-small ats-select-all"><?php _e('全選択', 'advanced-tag-search'); ?></button>
                                <button type="button" class="button button-small ats-deselect-all"><?php _e('全解除', 'advanced-tag-search'); ?></button>
                            </p>
                            <div class="ats-tag-checkbox-list">
                                <?php foreach ($all_wp_tags as $wp_tag): ?>
                                    <label class="ats-tag-checkbox">
                                        <input type="checkbox"
                                               name="ats_category_tags[<?php echo esc_attr($category_key); ?>][]"
                                               value="<?php echo esc_attr($wp_tag['name']); ?>"
                                               <?php checked(in_array($wp_tag['name'], $category_data['tags'], true)); ?>>
                                        <?php echo esc_html($wp_tag['name']); ?>
                                        <span class="ats-tag-count">(<?php echo intval($wp_tag['count']); ?>)</span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <p class="description">
                                <?php _e('このカテゴリーに表示するタグにチェックを入れてください。', 'advanced-tag-search'); ?>
                            </p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2"><hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;"></td>
                </tr>
                <?php endforeach; ?>
            </table>
            
            <h2><?php _e('カテゴリー絞り込み設定', 'advanced-tag-search'); ?></h2>
            <p><?php _e('検索モーダルの「カテゴリーから絞り込む」に表示するカテゴリーを選択してください。', 'advanced-tag-search'); ?></p>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label>
                            <?php _e('カテゴリー選択', 'advanced-tag-search'); ?>
                        </label>
                    </th>
                    <td>
                        <?php if (empty($all_wp_categories)): ?>
                            <p class="description">
                                <?php
                                printf(
                                    wp_kses(
                                        __('WordPressにカテゴリーが登録されていません。先に<a href="%s">カテゴリーを作成</a>してください。', 'advanced-tag-search'),
                                        array('a' => array('href' => array()))
                                    ),
                                    esc_url(admin_url('edit-tags.php?taxonomy=category'))
                                );
                                ?>
                            </p>
                        <?php else: ?>
                            <p class="ats-checkbox-toolbar">
                                <button type="button" class="button button-small ats-select-all"><?php _e('全選択', 'advanced-tag-search'); ?></button>
                                <button type="button" class="button button-small ats-deselect-all"><?php _e('全解除', 'advanced-tag-search'); ?></button>
                            </p>
                            <div class="ats-tag-checkbox-list">
                                <?php foreach ($all_wp_categories as $wp_category): ?>
                                    <label class="ats-tag-checkbox">
                                        <input type="checkbox"
                                               name="ats_filter_categories[]"
                                               value="<?php echo esc_attr($wp_category['slug']); ?>"
                                               <?php checked(null === $filter_categories || in_array($wp_category['slug'], $filter_categories, true)); ?>>
                                        <?php echo esc_html($wp_category['name']); ?>
                                        <span class="ats-tag-count">(<?php echo intval($wp_category['count']); ?>)</span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <p class="description">
                                <?php _e('モーダルに表示するカテゴリーにチェックを入れてください。すべて未選択の場合はカテゴリー絞り込みは表示されません。', 'advanced-tag-search'); ?>
                            </p>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <h2><?php _e('クイックリンク設定', 'advanced-tag-search'); ?></h2>
            <p>
                <?php _e('クイックリンクは、ブログのカテゴリーから自動生成されます（投稿のあるカテゴリーが対象）。「投稿」→「カテゴリー」で編集すると、検索窓の下のクイックリンクにも反映されます。', 'advanced-tag-search'); ?>
            </p>

            <h2><?php _e('ショートコード', 'advanced-tag-search'); ?></h2>
            <p><?php _e('以下のショートコードをページやウィジェットに貼り付けて使用してください。', 'advanced-tag-search'); ?></p>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e('基本的な使用', 'advanced-tag-search'); ?></th>
                    <td>
                        <code>[advanced_search]</code>
                        <p class="description">
                            <?php _e('検索窓、クイックリンク、モーダルを表示します。', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('カスタマイズ', 'advanced-tag-search'); ?></th>
                    <td>
                        <code>[advanced_search placeholder="検索してみる" show_quick_links="false"]</code>
                        <p class="description">
                            <?php _e('プレースホルダーやクイックリンクの表示をカスタマイズできます。', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('クイックリンクのみ', 'advanced-tag-search'); ?></th>
                    <td>
                        <code>[search_quick_links]</code>
                        <p class="description">
                            <?php _e('クイックリンクのみを表示します。', 'advanced-tag-search'); ?>
                        </p>
                    </td>
                </tr>
            </table>
            
            <?php submit_button(__('設定を保存', 'advanced-tag-search'), 'primary', 'ats_save_settings'); ?>
        </form>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // 全選択（同じ欄のチェックボックス一覧を対象）
        $(document).on('click', '.ats-select-all', function() {
            $(this).closest('td').find('.ats-tag-checkbox-list input[type="checkbox"]').prop('checked', true);
        });

        // 全解除
        $(document).on('click', '.ats-deselect-all', function() {
            $(this).closest('td').find('.ats-tag-checkbox-list input[type="checkbox"]').prop('checked', false);
        });
    });
    </script>
    <?php
}

/**
 * 設定の保存
 */
function ats_save_settings() {
    // 基本設定
    $settings = array(
        'search_title' => sanitize_text_field($_POST['ats_search_title'] ?? ''),
        'placeholder' => sanitize_text_field($_POST['ats_placeholder'] ?? ''),
        'modal_title' => sanitize_text_field($_POST['ats_modal_title'] ?? ''),
        'search_icon_color' => sanitize_hex_color($_POST['ats_search_icon_color'] ?? '#666666'),
        'button_color' => sanitize_hex_color($_POST['ats_button_color'] ?? '#2196F3'),
    );

    // モーダルに表示するカテゴリーの保存（チェックされたスラッグのみ。未チェックなら空配列）
    $filter_categories = array();
    if (isset($_POST['ats_filter_categories']) && is_array($_POST['ats_filter_categories'])) {
        $filter_categories = array_map('sanitize_title', $_POST['ats_filter_categories']);
    }
    $settings['filter_categories'] = $filter_categories;

    update_option('ats_settings', $settings);
    
    // タグカテゴリーの保存（チェックされたタグのみを保存）
    if (isset($_POST['ats_category_title'])) {
        $tag_categories = array();

        foreach ($_POST['ats_category_title'] as $category_key => $title) {
            // チェックされたタグを取得（未チェックの場合はPOSTに含まれないため空配列）
            $selected_tags = array();
            if (isset($_POST['ats_category_tags'][$category_key]) && is_array($_POST['ats_category_tags'][$category_key])) {
                $selected_tags = array_map('sanitize_text_field', $_POST['ats_category_tags'][$category_key]);
            }

            $tag_categories[sanitize_key($category_key)] = array(
                'title' => sanitize_text_field($title),
                'tags' => $selected_tags,
            );
        }

        update_option('ats_tag_categories', $tag_categories);
    }
}
