/**
 * Advanced Tag Search - Modal Control
 */

(function($) {
    'use strict';
    
    // 選択されたタグを保持する配列
    let selectedTags = [];

    // 選択されたカテゴリー(スラッグ)を保持する配列
    let selectedCategories = [];
    
    /**
     * 初期化処理
     */
    $(document).ready(function() {
        initModal();
        initTagSelection();
        initSearch();
    });
    
    /**
     * モーダルの初期化
     */
    function initModal() {
        // 検索窓クリックでモーダルを開く
        $(document).on('click', '#ats-search-input, .ats-search-button', function(e) {
            e.preventDefault();
            openModal();
        });
        
        // 閉じるボタンクリック
        $(document).on('click', '#ats-modal-close', function() {
            closeModal();
        });
        
        // オーバーレイクリックで閉じる
        $(document).on('click', '#ats-modal-overlay', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
        
        // ESCキーで閉じる
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $('#ats-modal-overlay').is(':visible')) {
                closeModal();
            }
        });
    }
    
    /**
     * タグ選択の初期化
     */
    function initTagSelection() {
        // タグの選択(カテゴリー絞り込みボタンは除外)
        $(document).on('click', '.ats-tag:not(.ats-category-filter)', function() {
            toggleTag($(this));
        });

        // カテゴリーの選択
        $(document).on('click', '.ats-category-filter', function() {
            toggleCategory($(this));
        });
    }
    
    /**
     * 検索機能の初期化
     */
    function initSearch() {
        $(document).on('click', '#ats-search-submit', function() {
            performSearch();
        });
    }
    
    /**
     * モーダルを開く
     */
    function openModal() {
        // 現在のスクロール位置を保存
        const scrollY = window.pageYOffset;
        $('body').data('scroll-position', scrollY);

        $('#ats-modal-overlay').fadeIn(300);
        // bodyのスクロールを無効化（背景のスクロールを防ぐ）
        $('body').css({
            'overflow': 'hidden',
            'touch-action': 'none'
        });
    }

    /**
     * モーダルを閉じる
     */
    function closeModal() {
        $('#ats-modal-overlay').fadeOut(300);
        // bodyのスクロールを復元
        $('body').css({
            'overflow': '',
            'touch-action': ''
        });

        // スクロール位置を復元
        const scrollY = $('body').data('scroll-position') || 0;
        window.scrollTo(0, scrollY);
    }
    
    /**
     * タグの選択/解除を切り替え
     */
    function toggleTag($tagElement) {
        const tagName = $tagElement.data('tag');
        
        if ($tagElement.hasClass('selected')) {
            // 選択解除
            $tagElement.removeClass('selected');
            selectedTags = selectedTags.filter(tag => tag !== tagName);
        } else {
            // 選択
            $tagElement.addClass('selected');
            selectedTags.push(tagName);
        }
        
        // 検索ボタンの状態を更新
        updateSearchButton();
    }

    /**
     * カテゴリーの選択/解除を切り替え
     */
    function toggleCategory($categoryElement) {
        const categorySlug = $categoryElement.data('category-slug');

        if ($categoryElement.hasClass('selected')) {
            // 選択解除
            $categoryElement.removeClass('selected');
            selectedCategories = selectedCategories.filter(slug => slug !== categorySlug);
        } else {
            // 選択
            $categoryElement.addClass('selected');
            selectedCategories.push(categorySlug);
        }

        // 検索ボタンの状態を更新
        updateSearchButton();
    }

    /**
     * 検索ボタンの状態を更新
     */
    function updateSearchButton() {
        const $submitButton = $('#ats-search-submit');
        const totalSelected = selectedTags.length + selectedCategories.length;

        $submitButton.prop('disabled', false);

        if (totalSelected > 0) {
            $submitButton.text('選択した条件で絞り込む (' + totalSelected + ')');
        } else {
            $submitButton.text('選択したタグで絞り込む');
        }
    }
    
    /**
     * 検索を実行
     */
    function performSearch() {
        if (selectedTags.length === 0 && selectedCategories.length === 0) {
            // タグもカテゴリーも選択されていない場合は通常の検索ページへ
            window.location.href = atsAjax.searchUrl;
            return;
        }

        // タグ・カテゴリー検索URLを構築
        // 複数選択の場合はカンマ区切りで連結
        const params = [];

        if (selectedTags.length > 0) {
            params.push('tag=' + encodeURIComponent(selectedTags.join(',')));
        }

        if (selectedCategories.length > 0) {
            params.push('ats_category=' + encodeURIComponent(selectedCategories.join(',')));
        }

        const searchUrl = atsAjax.searchUrl + '?' + params.join('&');

        // 検索ページへ遷移
        window.location.href = searchUrl;
    }
    
    /**
     * タグ検索用のクエリパラメータを処理
     * (WordPress側でカスタムクエリとして処理する必要があります)
     */
    function buildSearchQuery() {
        const params = new URLSearchParams();
        
        if (selectedTags.length > 0) {
            // タグをカンマ区切りで追加
            params.append('ats_tags', selectedTags.join(','));
        }
        
        return params.toString();
    }
    
    /**
     * Ajax検索(オプション機能)
     * ページ遷移せずに結果を表示したい場合に使用
     */
    function performAjaxSearch() {
        if (selectedTags.length === 0) {
            return;
        }

        $.ajax({
            url: atsAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'ats_search_posts',
                nonce: atsAjax.nonce,
                tags: selectedTags
            },
            beforeSend: function() {
                $('#ats-search-submit').prop('disabled', true).text('検索中...');
            },
            success: function(response) {
                if (response.success) {
                    // 検索結果を表示
                    displaySearchResults(response.data);
                    closeModal();
                }
            },
            error: function() {
                console.error('ATS: 検索エラーが発生しました');
            },
            complete: function() {
                $('#ats-search-submit').prop('disabled', false);
                updateSearchButton();
            }
        });
    }
    
    /**
     * 検索結果を表示(オプション機能)
     */
    function displaySearchResults(results) {
        // 検索結果の表示処理
        // 実装はサイトの要件に応じてカスタマイズ
        console.log('Search results:', results);
    }
    
    /**
     * タグをクリアする
     */
    function clearSelectedTags() {
        selectedTags = [];
        selectedCategories = [];
        $('.ats-tag').removeClass('selected');
        updateSearchButton();
    }
    
    /**
     * 公開API
     */
    window.ATS = {
        openModal: openModal,
        closeModal: closeModal,
        clearTags: clearSelectedTags,
        getSelectedTags: function() {
            return selectedTags.slice();
        },
        getSelectedCategories: function() {
            return selectedCategories.slice();
        }
    };
    
})(jQuery);
